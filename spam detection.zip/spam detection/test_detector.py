#!/usr/bin/env python3
"""
Quick test script to verify the spam detector works
"""

from spam_detector import train_model, predict_spam, HARDCODED_DATASET

def test_spam_detector():
    """Test the spam detector with example messages"""
    print("🧪 Testing Spam Detector\n")
    print("=" * 60)
    
    # Train the model
    model, vectorizer = train_model()
    
    # Test cases
    test_messages = [
        ("Congratulations! You won $1,000,000! Click here!", "Should be spam"),
        ("Meeting at 3pm tomorrow in room 201", "Should be ham"),
        ("Get rich quick! Make money online!", "Should be spam"),
        ("Can you review the document I sent?", "Should be ham"),
        ("Free pills! No prescription needed!", "Should be spam"),
    ]
    
    print("\n" + "=" * 60)
    print("📝 Running Test Cases")
    print("=" * 60 + "\n")
    
    for msg, expected in test_messages:
        prediction, confidence = predict_spam(model, vectorizer, msg)
        result = "🚫 SPAM" if prediction == 1 else "✅ HAM"
        print(f"Message: {msg}")
        print(f"Result: {result} ({confidence:.1f}% confidence)")
        print(f"Expected: {expected}\n")
        print("-" * 60 + "\n")
    
    print("✅ Testing complete!")

if __name__ == "__main__":
    test_spam_detector()


