#!/usr/bin/env python3
"""
🌐 Flask Web Application for Spam Mail Detector
Provides a beautiful web interface for the spam detection system
"""

from flask import Flask, render_template, request, jsonify
from spam_detector import train_model, predict_spam, load_model, save_model
import os

app = Flask(__name__)

# Global variables to store model
model = None
vectorizer = None

def initialize_model():
    """Initialize or load the model"""
    global model, vectorizer
    print("[*] Initializing spam detection model...")
    
    # Try to load existing model, else train new one
    model, vectorizer = load_model()
    
    if model is None or vectorizer is None:
        print("[*] Training new model...")
        model, vectorizer = train_model()
        save_model(model, vectorizer)
    
    print("[*] Model ready!")

# Initialize model on app startup
initialize_model()

@app.route('/')
def index():
    """Render the main page"""
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    """API endpoint to predict if a message is spam"""
    try:
        data = request.get_json()
        message = data.get('message', '').strip()
        
        if not message:
            return jsonify({
                'error': 'Message is required'
            }), 400
        
        # Predict
        prediction, confidence = predict_spam(model, vectorizer, message)
        
        # Format response - convert numpy bool_ to Python bool
        is_spam = bool(prediction == 1)
        result = {
            'is_spam': is_spam,
            'confidence': float(round(confidence, 2)),
            'label': 'SPAM' if is_spam else 'HAM',
            'message': message
        }
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500

@app.route('/health')
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'model_loaded': model is not None
    })

if __name__ == '__main__':
    print("\n" + "=" * 60)
    print("[*] Starting Spam Detector Web Application")
    print("=" * 60)
    print("\n[*] Open your browser and go to: http://localhost:5000\n")
    app.run(debug=True, host='0.0.0.0', port=5000)

