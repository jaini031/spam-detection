#!/usr/bin/env python3
"""
🚀 Spam Mail Detector
A lightweight Python-based spam detection system using Machine Learning
Built with scikit-learn, nltk, and a hardcoded dataset
"""

import re
import pickle
import string
from collections import Counter

try:
    import numpy as np
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.naive_bayes import MultinomialNB
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import accuracy_score, classification_report
    import nltk
    from nltk.corpus import stopwords
    from nltk.tokenize import word_tokenize
except ImportError as e:
    print(f"[-] Missing required library: {e}")
    print("[*] Installing required packages...")
    import subprocess
    subprocess.check_call(['pip', 'install', 'scikit-learn', 'nltk', 'numpy'])
    print("[+] Packages installed! Please run the script again.")
    exit()

# ═══════════════════════════════════════════════════════════
# 📊 HARDCODED DATASET - 15 examples for training
# ═══════════════════════════════════════════════════════════

HARDCODED_DATASET = {
    'messages': [
        # SPAM examples
        "Win a free iPhone today! Click here now!",
        "Claim your free gift card worth $500! Act now!",
        "Congratulations! You've won $1,000,000! Click to claim!",
        "URGENT: Claim your prize now! Limited time offer!",
        "Get rich quick! Make money from home today!",
        "Free pills! No prescription needed! Order now!",
        "You've been selected! Win a luxury vacation!",
        "Investment opportunity! Double your money in 24 hours!",
        
        # HAM (legitimate) examples
        "Meeting at 3pm in conference room B",
        "Don't forget to submit the report by Friday",
        "Thanks for the update, see you tomorrow",
        "Can you send me the presentation slides?",
        "Please review the attached document",
        "Team lunch scheduled for next Thursday at noon",
        "The project deadline has been extended to next month",
        "What time works best for our call tomorrow?"
    ],
    'labels': [
        'spam', 'spam', 'spam', 'spam', 'spam', 'spam', 'spam', 'spam',
        'ham', 'ham', 'ham', 'ham', 'ham', 'ham', 'ham', 'ham'
    ]
}


# ═══════════════════════════════════════════════════════════
# 🧹 TEXT PREPROCESSING
# ═══════════════════════════════════════════════════════════

def download_nltk_data():
    """Download required NLTK data if not already present"""
    try:
        nltk.data.find('tokenizers/punkt')
        nltk.data.find('corpora/stopwords')
    except LookupError:
        print("[*] Downloading NLTK data (one-time setup)...")
        nltk.download('punkt', quiet=True)
        nltk.download('stopwords', quiet=True)
        print("[+] NLTK data downloaded!")

def preprocess_text(text):
    """
    Clean and preprocess text data
    - Convert to lowercase
    - Remove punctuation
    - Remove stopwords
    """
    # Convert to lowercase
    text = text.lower()
    
    # Remove punctuation
    text = text.translate(str.maketrans('', '', string.punctuation))
    
    # Tokenize
    tokens = word_tokenize(text)
    
    # Remove stopwords
    stop_words = set(stopwords.words('english'))
    tokens = [word for word in tokens if word not in stop_words]
    
    # Join back to string
    return ' '.join(tokens)


# ═══════════════════════════════════════════════════════════
# 🤖 MODEL TRAINING
# ═══════════════════════════════════════════════════════════

def train_model():
    """Train the spam detection model using the hardcoded dataset"""
    print("\n[*] Training spam detection model...")
    
    # Download NLTK data if needed
    download_nltk_data()
    
    # Get data
    messages = HARDCODED_DATASET['messages']
    labels = HARDCODED_DATASET['labels']
    
    # Preprocess all messages
    print("[*] Preprocessing messages...")
    preprocessed_messages = [preprocess_text(msg) for msg in messages]
    
    # Create TF-IDF vectorizer
    print("[*] Creating feature vectors...")
    vectorizer = TfidfVectorizer(max_features=100, lowercase=True, token_pattern=r'\b\w+\b')
    X = vectorizer.fit_transform(preprocessed_messages)
    
    # Convert labels to binary (1 for spam, 0 for ham)
    y = [1 if label == 'spam' else 0 for label in labels]
    
    # Split data for testing accuracy
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    
    # Train Naive Bayes classifier
    print("[*] Training Multinomial Naive Bayes model...")
    model = MultinomialNB()
    model.fit(X_train, y_train)
    
    # Evaluate model
    print("[*] Evaluating model...")
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    
    print("\n" + "="*50)
    print(f"[+] Model trained successfully!")
    print(f"[*] Accuracy: {accuracy:.2%}")
    print("="*50 + "\n")
    
    # Show detailed classification report
    print("[*] Classification Report:")
    print(classification_report(y_test, y_pred, target_names=['Ham', 'Spam']))
    
    return model, vectorizer


# ═══════════════════════════════════════════════════════════
# 💾 SAVE/LOAD MODEL
# ═══════════════════════════════════════════════════════════

def save_model(model, vectorizer):
    """Save trained model and vectorizer to disk"""
    try:
        with open('spam_model.pkl', 'wb') as f:
            pickle.dump(model, f)
        with open('spam_vectorizer.pkl', 'wb') as f:
            pickle.dump(vectorizer, f)
        print("[*] Model saved to spam_model.pkl and spam_vectorizer.pkl")
    except Exception as e:
        print(f"[!] Could not save model: {e}")

def load_model():
    """Load previously trained model and vectorizer from disk"""
    try:
        with open('spam_model.pkl', 'rb') as f:
            model = pickle.load(f)
        with open('spam_vectorizer.pkl', 'rb') as f:
            vectorizer = pickle.load(f)
        print("[+] Loaded saved model from disk")
        return model, vectorizer
    except FileNotFoundError:
        print("[*] No saved model found. Training new model...")
        return None, None


# ═══════════════════════════════════════════════════════════
# 🔮 PREDICTION
# ═══════════════════════════════════════════════════════════

def predict_spam(model, vectorizer, text):
    """Predict if a message is spam or not"""
    # Preprocess the text
    preprocessed = preprocess_text(text)
    
    # Transform to TF-IDF
    text_vector = vectorizer.transform([preprocessed])
    
    # Predict
    prediction = model.predict(text_vector)[0]
    probability = model.predict_proba(text_vector)[0]
    
    # Get confidence
    confidence = probability[prediction] * 100
    
    return prediction, confidence


# ═══════════════════════════════════════════════════════════
# 🎮 CLI INTERFACE
# ═══════════════════════════════════════════════════════════

def main():
    """Main CLI interface for the spam detector"""
    print("=" * 60)
    print("  SPAM MAIL DETECTOR")
    print("=" * 60)
    
    # Try to load existing model, else train new one
    model, vectorizer = load_model()
    
    if model is None or vectorizer is None:
        model, vectorizer = train_model()
        save_model(model, vectorizer)
    
    print("\n" + "-" * 60)
    print("[*] Ready to detect spam! Enter 'quit' to exit.")
    print("-" * 60 + "\n")
    
    # Interactive loop
    while True:
        user_input = input("[*] Enter a message (or 'quit' to exit): ")
        
        if user_input.lower() == 'quit':
            print("\n[+] Thanks for using the Spam Detector! Goodbye!\n")
            break
        
        if not user_input.strip():
            print("[!] Please enter a valid message.\n")
            continue
        
        # Predict
        prediction, confidence = predict_spam(model, vectorizer, user_input)
        
        # Display result
        print("\n" + "-" * 60)
        if prediction == 1:
            print(f"[!] RESULT: SPAM detected!")
            print(f"[*] Confidence: {confidence:.1f}%")
        else:
            print(f"[+] RESULT: Not Spam (Ham)")
            print(f"[*] Confidence: {confidence:.1f}%")
        print("-" * 60 + "\n")


# ═══════════════════════════════════════════════════════════
# 🚀 ENTRY POINT
# ═══════════════════════════════════════════════════════════

if __name__ == "__main__":
    main()

