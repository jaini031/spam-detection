# 🚀 Quick Start Guide

Get the Spam Mail Detector up and running in 3 steps!

## Step 1: Install Dependencies

```bash
pip install -r requirements.txt
```

This installs:
- scikit-learn (ML library)
- nltk (text processing)
- numpy (numerical operations)
- flask (web framework)

## Step 2: Choose Your Interface

### Option A: Web Interface (Recommended) 🌐

Run:
```bash
python app.py
```

Or on Windows:
```bash
start_web.bat
```

Then open: **http://localhost:5000**

Features:
- ✨ Beautiful, modern UI
- 🎯 One-click analysis
- 📊 Confidence visualization
- 💡 Example messages to try

### Option B: Command Line Interface 💻

Run:
```bash
python spam_detector.py
```

Features:
- 🔄 Interactive prompt
- 📧 Enter messages directly
- ✅ Quick results

## Step 3: Start Detecting!

Try these examples:

**Spam:**
- "Win a free iPhone today!"
- "Congratulations! You won $1,000,000!"
- "Get rich quick! Make money online!"

**Ham (Not Spam):**
- "Meeting at 3pm tomorrow"
- "Can you review the document?"
- "Please submit the report by Friday"

## 🎯 Tips

- First run will download NLTK data automatically
- Model trains in seconds
- Results get cached for faster subsequent runs
- Works offline after initial setup

## 🐛 Troubleshooting

**"Module not found" error?**
```bash
pip install -r requirements.txt
```

**NLTK download issues?**
- Check your internet connection (needed once)
- The script will auto-download required data

**Port 5000 already in use?**
- Edit `app.py` and change `port=5000` to another port

Happy detecting! 🎉



